import { useAppStore } from '../../store/useAppStore';
import { CATEGORY_CONFIG, type OpportunityStatus } from '../../types';
import { generateActionSuggestion, getHeatLabel, formatDate, calculateTrend, getTrendIcon, getTrendColor } from '../../utils/actionEngine';

// 状态按钮配置
const STATUS_CONFIG: Record<OpportunityStatus, { label: string; icon: string; color: string }> = {
  none: { label: '未关注', icon: '○', color: '#6b7280' },
  watching: { label: '已关注', icon: '👁', color: '#3b82f6' },
  in_progress: { label: '进行中', icon: '🔄', color: '#f59e0b' },
  completed: { label: '已完成', icon: '✓', color: '#22c55e' },
};

// 机会详情面板
const ActionPanel: React.FC = () => {
  const { 
    selectedOpportunity, 
    userRole, 
    setUserRole, 
    isPanelOpen, 
    setSelectedOpportunity,
    watchedOpportunities,
    setOpportunityStatus
  } = useAppStore();
  
  if (!isPanelOpen || !selectedOpportunity) return null;
  
  const opp = selectedOpportunity;
  const config = CATEGORY_CONFIG[opp.category];
  const action = generateActionSuggestion(opp, userRole);
  const heatInfo = getHeatLabel(opp.heat);
  const trend = calculateTrend(opp.heatHistory);
  const currentStatus = watchedOpportunities.get(opp.id) || 'none';
  
  return (
    <div className="absolute right-0 top-0 h-full w-[380px] bg-[#0d0d15]/95 backdrop-blur-md border-l border-white/10 z-20 overflow-y-auto">
      {/* 头部 */}
      <div className="sticky top-0 bg-[#0d0d15]/95 backdrop-blur-md border-b border-white/10 p-4 z-10">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <span 
                className="text-xs px-2 py-1 rounded-full"
                style={{ backgroundColor: config.color + '30', color: config.glowColor }}
              >
                {config.label}
              </span>
              <span 
                className="text-xs px-2 py-1 rounded-full"
                style={{ backgroundColor: heatInfo.color + '30', color: heatInfo.color }}
              >
                {heatInfo.label}
              </span>
            </div>
            <h2 className="text-lg font-semibold text-white leading-tight">
              {opp.title}
            </h2>
          </div>
          <button
            onClick={() => setSelectedOpportunity(null)}
            className="text-gray-400 hover:text-white transition-colors p-1"
          >
            ✕
          </button>
        </div>
      </div>
      
      {/* 内容 */}
      <div className="p-4 space-y-4">
        {/* 摘要 */}
        <div>
          <p className="text-gray-300 text-sm leading-relaxed">{opp.summary}</p>
        </div>
        
        {/* 元信息 */}
        <div className="flex flex-wrap gap-3 text-xs text-gray-400">
          <div className="flex items-center gap-1">
            <span>🔥</span>
            <span className="text-yellow-400 font-medium">{opp.heat}</span>
            <span style={{ color: getTrendColor(trend) }}>{getTrendIcon(trend)}</span>
          </div>
          <div className="flex items-center gap-1">
            <span>📅</span>
            <span>{formatDate(opp.publishDate)}</span>
          </div>
          <div className="flex items-center gap-1">
            <span>🔗</span>
            <a 
              href={opp.sourceUrl} 
              target="_blank" 
              rel="noopener noreferrer"
              className="text-blue-400 hover:underline"
            >
              {opp.source}
            </a>
          </div>
        </div>
        
        {/* 标签 */}
        <div className="flex flex-wrap gap-2">
          {opp.tags.map(tag => (
            <span 
              key={tag}
              className="text-xs px-2 py-1 bg-white/5 rounded-full text-gray-300"
            >
              #{tag}
            </span>
          ))}
        </div>
        
        {/* 状态切换 */}
        <div className="border-t border-white/10 pt-4">
          <div className="text-xs text-gray-400 mb-2">追踪状态</div>
          <div className="flex gap-2">
            {(Object.keys(STATUS_CONFIG) as OpportunityStatus[]).map(status => {
              const statusConfig = STATUS_CONFIG[status];
              const isActive = currentStatus === status;
              return (
                <button
                  key={status}
                  onClick={() => setOpportunityStatus(opp.id, status)}
                  className={`px-3 py-1.5 rounded-lg text-xs transition-all ${
                    isActive 
                      ? 'bg-white/20 text-white' 
                      : 'bg-white/5 text-gray-400 hover:bg-white/10'
                  }`}
                  style={isActive ? { borderColor: statusConfig.color, borderWidth: '1px' } : {}}
                >
                  {statusConfig.icon} {statusConfig.label}
                </button>
              );
            })}
          </div>
        </div>
        
        {/* 角色切换 */}
        <div className="border-t border-white/10 pt-4">
          <div className="text-xs text-gray-400 mb-2">查看视角</div>
          <div className="flex gap-2">
            <button
              onClick={() => setUserRole('developer')}
              className={`flex-1 py-2 rounded-lg text-sm transition-all ${
                userRole === 'developer'
                  ? 'bg-blue-500/30 text-blue-300 border border-blue-500/50'
                  : 'bg-white/5 text-gray-400 hover:bg-white/10'
              }`}
            >
              👨‍💻 开发者
            </button>
            <button
              onClick={() => setUserRole('entrepreneur')}
              className={`flex-1 py-2 rounded-lg text-sm transition-all ${
                userRole === 'entrepreneur'
                  ? 'bg-amber-500/30 text-amber-300 border border-amber-500/50'
                  : 'bg-white/5 text-gray-400 hover:bg-white/10'
              }`}
            >
              💼 创业者
            </button>
          </div>
        </div>
        
        {/* 行动建议 */}
        <div className="border-t border-white/10 pt-4">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-lg">🚀</span>
            <span className="text-sm font-medium text-white">行动建议</span>
            <span className={`text-xs px-2 py-0.5 rounded ${
              action.difficulty === 'easy' ? 'bg-green-500/20 text-green-400' :
              action.difficulty === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
              'bg-red-500/20 text-red-400'
            }`}>
              {action.difficulty === 'easy' ? '简单' : action.difficulty === 'medium' ? '中等' : '困难'}
            </span>
            <span className="text-xs text-gray-400">⏱ {action.estimatedTime}</span>
          </div>
          
          <h3 className="text-white font-medium mb-3">{action.title}</h3>
          
          {/* 步骤 */}
          <div className="space-y-2 mb-4">
            {action.steps.map((step, index) => (
              <div key={index} className="flex items-start gap-2">
                <span className="flex-shrink-0 w-5 h-5 rounded-full bg-white/10 text-xs flex items-center justify-center text-gray-300">
                  {index + 1}
                </span>
                <span className="text-sm text-gray-300">{step}</span>
              </div>
            ))}
          </div>
          
          {/* 资源链接 */}
          {action.resources.length > 0 && (
            <div>
              <div className="text-xs text-gray-400 mb-2">参考资源</div>
              <div className="space-y-1">
                {action.resources.map((resource, index) => (
                  <a
                    key={index}
                    href={resource.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-2 text-sm text-blue-400 hover:text-blue-300 hover:underline"
                  >
                    <span>📎</span>
                    <span>{resource.name}</span>
                  </a>
                ))}
              </div>
            </div>
          )}
        </div>
        
        {/* 关联主题 */}
        {opp.relatedIds.length > 0 && (
          <div className="border-t border-white/10 pt-4">
            <div className="text-xs text-gray-400 mb-2">关联机会</div>
            <div className="text-sm text-gray-300">
              {opp.relatedIds.length} 个相关机会在星图中以连线标注
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ActionPanel;
