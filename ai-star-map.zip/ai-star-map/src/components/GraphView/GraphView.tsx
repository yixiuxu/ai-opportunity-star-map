import { useMemo } from 'react';
import ForceGraph2D from 'react-force-graph-2d';
import { useAppStore } from '../../store/useAppStore';
import { CATEGORY_CONFIG } from '../../types';
import type { Opportunity } from '../../types';

// 图谱节点数据
interface GraphNode {
  id: string;
  title: string;
  category: Opportunity['category'];
  heat: number;
  x?: number;
  y?: number;
}

interface GraphLink {
  source: string;
  target: string;
}

const GraphView: React.FC = () => {
  const { getFilteredOpportunities, setSelectedOpportunity, selectedOpportunity } = useAppStore();
  const filteredOpps = getFilteredOpportunities();
  
  // 构建图谱数据
  const graphData = useMemo(() => {
    const nodes: GraphNode[] = filteredOpps.map(opp => ({
      id: opp.id,
      title: opp.title,
      category: opp.category,
      heat: opp.heat,
    }));
    
    const links: GraphLink[] = [];
    filteredOpps.forEach(opp => {
      opp.relatedIds.forEach(relatedId => {
        if (opp.id < relatedId && filteredOpps.find(o => o.id === relatedId)) {
          links.push({
            source: opp.id,
            target: relatedId,
          });
        }
      });
    });
    
    return { nodes, links };
  }, [filteredOpps]);
  
  // 绘制节点
  const paintNode = (node: GraphNode, ctx: CanvasRenderingContext2D, globalScale: number) => {
    const config = CATEGORY_CONFIG[node.category];
    const size = 4 + (node.heat / 100) * 8;
    const isSelected = selectedOpportunity?.id === node.id;
    
    // 绘制光晕
    if (isSelected) {
      ctx.beginPath();
      ctx.arc(node.x || 0, node.y || 0, size * 2, 0, 2 * Math.PI);
      ctx.fillStyle = config.color + '40';
      ctx.fill();
    }
    
    // 绘制节点
    ctx.beginPath();
    ctx.arc(node.x || 0, node.y || 0, size, 0, 2 * Math.PI);
    ctx.fillStyle = config.color;
    ctx.fill();
    
    // 绘制标签（缩放足够大时）
    if (globalScale > 0.8) {
      const label = node.title.length > 15 ? node.title.slice(0, 15) + '...' : node.title;
      ctx.font = `${10}px Inter, sans-serif`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillStyle = '#ffffff';
      ctx.fillText(label, node.x || 0, (node.y || 0) + size + 12);
    }
  };
  
  return (
    <div className="w-full h-full bg-[#050510]">
      <ForceGraph2D
        graphData={graphData}
        nodeRelSize={6}
        nodeCanvasObject={paintNode}
        onNodeClick={(node) => {
          const opp = filteredOpps.find(o => o.id === node.id);
          if (opp) setSelectedOpportunity(opp);
        }}
        linkColor={() => 'rgba(255, 255, 255, 0.1)'}
        linkWidth={1}
        linkDirectionalParticles={2}
        linkDirectionalParticleSpeed={0.005}
        linkDirectionalParticleColor={() => 'rgba(255, 255, 255, 0.3)'}
        backgroundColor="#050510"
        enableZoomInteraction={true}
        enablePanInteraction={true}
        minZoom={0.2}
        maxZoom={3}
        cooldownTicks={100}
        d3AlphaDecay={0.02}
        d3VelocityDecay={0.3}
      />
    </div>
  );
};

export default GraphView;
