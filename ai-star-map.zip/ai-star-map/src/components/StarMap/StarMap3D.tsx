import { useRef, useMemo, useState } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import { Stars, OrbitControls, Html, Float, Line } from '@react-three/drei';
import * as THREE from 'three';
import { useAppStore } from '../../store/useAppStore';
import { CATEGORY_CONFIG } from '../../types';
import type { Opportunity } from '../../types';

// 星球节点组件
const StarNode: React.FC<{ 
  opportunity: Opportunity; 
  position: [number, number, number];
  onClick: () => void;
  isSelected: boolean;
}> = ({ opportunity, position, onClick, isSelected }) => {
  const meshRef = useRef<THREE.Mesh>(null);
  const [hovered, setHovered] = useState(false);
  
  const config = CATEGORY_CONFIG[opportunity.category];
  const baseSize = 0.3 + (opportunity.heat / 100) * 0.8;
  const size = hovered || isSelected ? baseSize * 1.3 : baseSize;
  
  // 脉动动画
  useFrame((state) => {
    if (meshRef.current) {
      const pulse = Math.sin(state.clock.elapsedTime * 2 + opportunity.heat / 20) * 0.05;
      meshRef.current.scale.setScalar(size + pulse);
    }
  });
  
  return (
    <Float speed={1} rotationIntensity={0.2} floatIntensity={0.3}>
      <group position={position}>
        {/* 发光效果 */}
        <mesh>
          <sphereGeometry args={[size * 1.5, 16, 16]} />
          <meshBasicMaterial 
            color={config.color} 
            transparent 
            opacity={hovered || isSelected ? 0.3 : 0.15} 
          />
        </mesh>
        
        {/* 主体球 */}
        <mesh
          ref={meshRef}
          onClick={(e) => {
            e.stopPropagation();
            onClick();
          }}
          onPointerOver={(e) => {
            e.stopPropagation();
            setHovered(true);
            document.body.style.cursor = 'pointer';
          }}
          onPointerOut={() => {
            setHovered(false);
            document.body.style.cursor = 'default';
          }}
        >
          <sphereGeometry args={[size, 32, 32]} />
          <meshStandardMaterial 
            color={config.color}
            emissive={config.glowColor}
            emissiveIntensity={hovered || isSelected ? 0.8 : 0.4}
            roughness={0.3}
            metalness={0.7}
          />
        </mesh>
        
        {/* 悬停标签 */}
        {(hovered || isSelected) && (
          <Html
            center
            distanceFactor={10}
            style={{
              pointerEvents: 'none',
              whiteSpace: 'nowrap',
            }}
          >
            <div className="bg-black/80 backdrop-blur-sm px-3 py-2 rounded-lg border border-white/20">
              <div className="text-white font-medium text-sm max-w-[200px] truncate">
                {opportunity.title}
              </div>
              <div className="flex items-center gap-2 mt-1">
                <span 
                  className="text-xs px-1.5 py-0.5 rounded"
                  style={{ backgroundColor: config.color + '40', color: config.glowColor }}
                >
                  {config.label}
                </span>
                <span className="text-xs text-yellow-400">🔥 {opportunity.heat}</span>
              </div>
            </div>
          </Html>
        )}
      </group>
    </Float>
  );
};

// 连接线组件
const ConnectionLines: React.FC<{ opportunities: (Opportunity & { position: [number, number, number] })[] }> = ({ opportunities }) => {
  const lines = useMemo(() => {
    const result: { start: [number, number, number]; end: [number, number, number]; key: string }[] = [];
    
    opportunities.forEach(opp => {
      opp.relatedIds.forEach(relatedId => {
        const related = opportunities.find(o => o.id === relatedId);
        if (related && opp.id < relatedId) {
          result.push({
            start: opp.position,
            end: related.position,
            key: `${opp.id}-${relatedId}`
          });
        }
      });
    });
    
    return result;
  }, [opportunities]);
  
  return (
    <>
      {lines.map(({ start, end, key }) => (
        <Line
          key={key}
          points={[start, end]}
          color="#ffffff"
          opacity={0.1}
          transparent
          lineWidth={1}
        />
      ))}
    </>
  );
};

// 场景组件
const Scene: React.FC = () => {
  const { getFilteredOpportunities, selectedOpportunity, setSelectedOpportunity } = useAppStore();
  const filteredOpps = getFilteredOpportunities();
  
  // 为每个机会分配3D位置
  const opportunitiesWithPositions = useMemo(() => {
    return filteredOpps.map((opp, index) => {
      // 使用黄金角度分布
      const phi = Math.acos(1 - 2 * (index + 0.5) / filteredOpps.length);
      const theta = Math.PI * (1 + Math.sqrt(5)) * index;
      
      const radius = 8 + (100 - opp.heat) * 0.1; // 热度高的更靠近中心
      
      return {
        ...opp,
        position: [
          radius * Math.sin(phi) * Math.cos(theta),
          radius * Math.sin(phi) * Math.sin(theta),
          radius * Math.cos(phi)
        ] as [number, number, number]
      };
    });
  }, [filteredOpps]);
  
  return (
    <>
      {/* 环境光 */}
      <ambientLight intensity={0.2} />
      <pointLight position={[10, 10, 10]} intensity={1} />
      <pointLight position={[-10, -10, -10]} intensity={0.5} />
      
      {/* 星空背景 */}
      <Stars 
        radius={100} 
        depth={50} 
        count={5000} 
        factor={4} 
        saturation={0} 
        fade 
        speed={1}
      />
      
      {/* 连接线 */}
      <ConnectionLines opportunities={opportunitiesWithPositions} />
      
      {/* 星球节点 */}
      {opportunitiesWithPositions.map((opp) => (
        <StarNode
          key={opp.id}
          opportunity={opp}
          position={opp.position}
          onClick={() => setSelectedOpportunity(opp)}
          isSelected={selectedOpportunity?.id === opp.id}
        />
      ))}
      
      {/* 轨道控制 */}
      <OrbitControls 
        enablePan={false}
        enableZoom={true}
        minDistance={5}
        maxDistance={30}
        autoRotate
        autoRotateSpeed={0.3}
      />
    </>
  );
};

// 主组件
const StarMap3D: React.FC = () => {
  return (
    <div className="w-full h-full bg-[#050510]">
      <Canvas
        camera={{ position: [0, 0, 20], fov: 60 }}
        gl={{ antialias: true, alpha: true }}
      >
        <Scene />
      </Canvas>
    </div>
  );
};

export default StarMap3D;
