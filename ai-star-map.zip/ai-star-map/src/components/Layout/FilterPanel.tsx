import { useAppStore } from '../../store/useAppStore';
import { CATEGORY_CONFIG, type Category } from '../../types';
import { getAllTags } from '../../data/mockData';

const FilterPanel: React.FC = () => {
  const { 
    filters, 
    setFilters, 
    isFilterOpen, 
    toggleFilter,
    getFilteredOpportunities
  } = useAppStore();
  
  const filteredCount = getFilteredOpportunities().length;
  const allTags = getAllTags();
  
  if (!isFilterOpen) {
    return (
      <button
        onClick={toggleFilter}
        className="absolute left-4 top-20 z-20 px-3 py-2 bg-white/5 hover:bg-white/10 rounded-lg text-sm text-gray-400 hover:text-white transition-all border border-white/10"
      >
        ☰ 筛选
      </button>
    );
  }
  
  return (
    <aside className="absolute left-0 top-14 h-[calc(100%-3.5rem)] w-56 bg-[#0d0d15]/95 backdrop-blur-md border-r border-white/10 z-20 overflow-y-auto">
      <div className="p-4">
        {/* 头部 */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-sm font-medium text-white">筛选条件</h3>
          <button
            onClick={toggleFilter}
            className="text-gray-400 hover:text-white"
          >
            ✕
          </button>
        </div>
        
        {/* 结果计数 */}
        <div className="mb-4 px-3 py-2 bg-white/5 rounded-lg text-xs text-gray-400">
          显示 <span className="text-white font-medium">{filteredCount}</span> 个机会
        </div>
        
        {/* 类别筛选 */}
        <div className="mb-4">
          <div className="text-xs text-gray-400 mb-2">类别</div>
          <div className="space-y-1">
            {(Object.keys(CATEGORY_CONFIG) as Category[]).map(category => {
              const config = CATEGORY_CONFIG[category];
              const isActive = filters.categories.includes(category);
              return (
                <button
                  key={category}
                  onClick={() => {
                    const newCategories = isActive
                      ? filters.categories.filter(c => c !== category)
                      : [...filters.categories, category];
                    setFilters({ categories: newCategories });
                  }}
                  className={`w-full flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm transition-all ${
                    isActive 
                      ? 'bg-white/15 text-white' 
                      : 'text-gray-400 hover:bg-white/5 hover:text-white'
                  }`}
                >
                  <span 
                    className="w-2 h-2 rounded-full"
                    style={{ backgroundColor: config.color }}
                  />
                  <span>{config.label}</span>
                </button>
              );
            })}
          </div>
        </div>
        
        {/* 热度筛选 */}
        <div className="mb-4">
          <div className="text-xs text-gray-400 mb-2">
            热度范围: {filters.minHeat} - {filters.maxHeat}
          </div>
          <div className="space-y-2">
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500 w-8">最低</span>
              <input
                type="range"
                min="0"
                max="100"
                value={filters.minHeat}
                onChange={(e) => setFilters({ minHeat: parseInt(e.target.value) })}
                className="flex-1 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-xs text-gray-400 w-8">{filters.minHeat}</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xs text-gray-500 w-8">最高</span>
              <input
                type="range"
                min="0"
                max="100"
                value={filters.maxHeat}
                onChange={(e) => setFilters({ maxHeat: parseInt(e.target.value) })}
                className="flex-1 h-1 bg-white/10 rounded-lg appearance-none cursor-pointer"
              />
              <span className="text-xs text-gray-400 w-8">{filters.maxHeat}</span>
            </div>
          </div>
        </div>
        
        {/* 标签筛选 */}
        <div className="mb-4">
          <div className="text-xs text-gray-400 mb-2">热门标签</div>
          <div className="flex flex-wrap gap-1">
            {allTags.slice(0, 15).map(tag => {
              const isActive = filters.tags.includes(tag);
              return (
                <button
                  key={tag}
                  onClick={() => {
                    const newTags = isActive
                      ? filters.tags.filter(t => t !== tag)
                      : [...filters.tags, tag];
                    setFilters({ tags: newTags });
                  }}
                  className={`px-2 py-0.5 rounded text-xs transition-all ${
                    isActive 
                      ? 'bg-blue-500/30 text-blue-300' 
                      : 'bg-white/5 text-gray-400 hover:bg-white/10'
                  }`}
                >
                  #{tag}
                </button>
              );
            })}
          </div>
        </div>
        
        {/* 重置按钮 */}
        <button
          onClick={() => setFilters({
            categories: [],
            minHeat: 0,
            maxHeat: 100,
            dateRange: ['2026-04-01', '2026-05-31'],
            searchQuery: '',
            tags: [],
          })}
          className="w-full py-2 bg-white/5 hover:bg-white/10 rounded-lg text-sm text-gray-400 hover:text-white transition-all"
        >
          重置筛选
        </button>
      </div>
    </aside>
  );
};

export default FilterPanel;
