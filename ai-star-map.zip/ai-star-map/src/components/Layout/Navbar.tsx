import { useAppStore } from '../../store/useAppStore';
import type { ViewType, UserRole } from '../../types';

const VIEW_CONFIG: Record<ViewType, { label: string; icon: string }> = {
  starmap: { label: '机会星图', icon: '🌌' },
  graph: { label: '关系图谱', icon: '🕸️' },
  timeline: { label: '趋势时间线', icon: '📈' },
};

const ROLE_CONFIG: Record<UserRole, { label: string; icon: string }> = {
  developer: { label: '开发者', icon: '👨‍💻' },
  entrepreneur: { label: '创业者', icon: '💼' },
};

const Navbar: React.FC = () => {
  const { 
    currentView, 
    setCurrentView, 
    userRole, 
    setUserRole,
    filters,
    setFilters,
    getWatchedCount
  } = useAppStore();
  
  const watchedCount = getWatchedCount();
  
  return (
    <header className="h-14 bg-[#0a0a12]/90 backdrop-blur-md border-b border-white/10 flex items-center justify-between px-4 z-30">
      {/* Logo */}
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <span className="text-xl">✨</span>
          <h1 className="text-lg font-semibold text-white whitespace-nowrap">
            AI机会星图
          </h1>
        </div>
        <span className="text-xs text-gray-500 hidden sm:inline">TRAE SOLO</span>
      </div>
      
      {/* 视图切换 */}
      <nav className="flex items-center gap-1 bg-white/5 rounded-lg p-1">
        {(Object.keys(VIEW_CONFIG) as ViewType[]).map(view => {
          const config = VIEW_CONFIG[view];
          const isActive = currentView === view;
          return (
            <button
              key={view}
              onClick={() => setCurrentView(view)}
              className={`px-3 py-1.5 rounded-md text-sm transition-all ${
                isActive 
                  ? 'bg-white/15 text-white' 
                  : 'text-gray-400 hover:text-white hover:bg-white/5'
              }`}
            >
              <span className="mr-1.5">{config.icon}</span>
              <span className="hidden sm:inline">{config.label}</span>
            </button>
          );
        })}
      </nav>
      
      {/* 右侧工具栏 */}
      <div className="flex items-center gap-3">
        {/* 搜索框 */}
        <div className="relative">
          <input
            type="text"
            placeholder="搜索机会..."
            value={filters.searchQuery}
            onChange={(e) => setFilters({ searchQuery: e.target.value })}
            className="w-40 sm:w-48 px-3 py-1.5 pl-8 bg-white/5 border border-white/10 rounded-lg text-sm text-white placeholder-gray-500 focus:outline-none focus:border-white/30"
          />
          <span className="absolute left-2.5 top-1/2 -translate-y-1/2 text-gray-500">🔍</span>
        </div>
        
        {/* 角色切换 */}
        <div className="flex items-center gap-1 bg-white/5 rounded-lg p-1">
          {(Object.keys(ROLE_CONFIG) as UserRole[]).map(role => {
            const config = ROLE_CONFIG[role];
            const isActive = userRole === role;
            return (
              <button
                key={role}
                onClick={() => setUserRole(role)}
                className={`px-2 py-1 rounded-md text-xs transition-all ${
                  isActive 
                    ? 'bg-white/15 text-white' 
                    : 'text-gray-400 hover:text-white'
                }`}
                title={config.label}
              >
                {config.icon}
              </button>
            );
          })}
        </div>
        
        {/* 追踪计数 */}
        {watchedCount > 0 && (
          <div className="flex items-center gap-1.5 px-2 py-1 bg-blue-500/20 rounded-lg text-xs text-blue-300">
            <span>👁</span>
            <span>{watchedCount}</span>
          </div>
        )}
      </div>
    </header>
  );
};

export default Navbar;
