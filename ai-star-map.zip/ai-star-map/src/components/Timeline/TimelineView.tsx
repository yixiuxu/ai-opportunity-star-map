import { useMemo } from 'react';
import ReactECharts from 'echarts-for-react';
import { useAppStore } from '../../store/useAppStore';
import { CATEGORY_CONFIG } from '../../types';

const TimelineView: React.FC = () => {
  const { getFilteredOpportunities, setSelectedOpportunity } = useAppStore();
  const filteredOpps = getFilteredOpportunities();
  
  // 构建图表数据
  const chartOption = useMemo(() => {
    // 生成日期序列（最近7天）
    const dates: string[] = [];
    for (let i = 6; i >= 0; i--) {
      const date = new Date();
      date.setDate(date.getDate() - i);
      dates.push(date.toISOString().split('T')[0]);
    }
    
    // 构建河流图数据
    const seriesData: Record<string, [string, number, number][]> = {};
    
    filteredOpps.forEach(opp => {
      if (!seriesData[opp.category]) {
        seriesData[opp.category] = [];
      }
      
      // 使用热度历史数据
      opp.heatHistory.forEach((heat, index) => {
        const date = dates[index] || dates[0];
        seriesData[opp.category].push([date, heat, heat]);
      });
    });
    
    // 合并同一天的同类数据
    const mergedData: Record<string, Map<string, number>> = {};
    Object.entries(seriesData).forEach(([category, data]) => {
      mergedData[category] = new Map();
      data.forEach(([date, value]) => {
        const current = mergedData[category].get(date) || 0;
        mergedData[category].set(date, current + value);
      });
    });
    
    // 构建系列
    const series = Object.entries(mergedData).map(([category, dataMap]) => {
      const config = CATEGORY_CONFIG[category as keyof typeof CATEGORY_CONFIG];
      const data = dates.map(date => {
        const value = dataMap.get(date) || 0;
        return [date, value, value, category];
      });
      
      return {
        name: config.label,
        type: 'themeRiver' as const,
        emphasis: {
          focus: 'series' as const,
        },
        data,
        itemStyle: {
          color: config.color,
        },
      };
    });
    
    return {
      tooltip: {
        trigger: 'axis' as const,
        axisPointer: {
          type: 'line' as const,
          lineStyle: {
            color: 'rgba(255, 255, 255, 0.2)',
          },
        },
        backgroundColor: 'rgba(13, 13, 21, 0.95)',
        borderColor: 'rgba(255, 255, 255, 0.1)',
        textStyle: {
          color: '#fff',
        },
        formatter: (params: any) => {
          if (!Array.isArray(params)) return '';
          const date = params[0]?.data?.[0] || '';
          let html = `<div style="font-weight: 600; margin-bottom: 8px;">${date}</div>`;
          params.forEach((item: any) => {
            const value = Math.round(item.data?.[1] / filteredOpps.filter(o => 
              CATEGORY_CONFIG[o.category].label === item.seriesName
            ).length) || 0;
            html += `
              <div style="display: flex; align-items: center; gap: 8px; margin: 4px 0;">
                <span style="display: inline-block; width: 10px; height: 10px; border-radius: 50%; background: ${item.color};"></span>
                <span>${item.seriesName}</span>
                <span style="margin-left: auto; font-weight: 600;">${value}</span>
              </div>
            `;
          });
          return html;
        },
      },
      legend: {
        data: Object.keys(CATEGORY_CONFIG).map(c => CATEGORY_CONFIG[c as keyof typeof CATEGORY_CONFIG].label),
        bottom: 10,
        textStyle: {
          color: '#9ca3af',
        },
        itemWidth: 12,
        itemHeight: 12,
        itemGap: 16,
      },
      grid: {
        left: 60,
        right: 40,
        top: 40,
        bottom: 80,
      },
      xAxis: {
        type: 'time' as const,
        axisLine: {
          lineStyle: {
            color: 'rgba(255, 255, 255, 0.1)',
          },
        },
        axisLabel: {
          color: '#9ca3af',
          fontSize: 11,
        },
        splitLine: {
          show: false,
        },
      },
      yAxis: {
        type: 'value' as const,
        axisLine: {
          show: false,
        },
        axisLabel: {
          color: '#9ca3af',
          fontSize: 11,
        },
        splitLine: {
          lineStyle: {
            color: 'rgba(255, 255, 255, 0.05)',
          },
        },
      },
      series,
      backgroundColor: 'transparent',
    };
  }, [filteredOpps]);
  
  // 热门机会列表
  const topOpportunities = useMemo(() => {
    return [...filteredOpps]
      .sort((a, b) => b.heat - a.heat)
      .slice(0, 10);
  }, [filteredOpps]);
  
  return (
    <div className="w-full h-full bg-[#050510] flex">
      {/* 图表区域 */}
      <div className="flex-1 p-4">
        <div className="h-full flex flex-col">
          <h3 className="text-sm font-medium text-white mb-4">📈 热度趋势河流图</h3>
          <div className="flex-1">
            <ReactECharts
              option={chartOption}
              style={{ height: '100%', width: '100%' }}
              opts={{ renderer: 'canvas' }}
            />
          </div>
        </div>
      </div>
      
      {/* 热门机会列表 */}
      <div className="w-80 border-l border-white/10 p-4 overflow-y-auto">
        <h3 className="text-sm font-medium text-white mb-4">🔥 热门机会 TOP 10</h3>
        <div className="space-y-2">
          {topOpportunities.map((opp, index) => {
            const config = CATEGORY_CONFIG[opp.category];
            return (
              <button
                key={opp.id}
                onClick={() => setSelectedOpportunity(opp)}
                className="w-full text-left p-3 bg-white/5 hover:bg-white/10 rounded-lg transition-all group"
              >
                <div className="flex items-start gap-2">
                  <span className="text-xs text-gray-500 font-mono">#{index + 1}</span>
                  <div className="flex-1 min-w-0">
                    <div className="text-sm text-white truncate group-hover:text-blue-300">
                      {opp.title}
                    </div>
                    <div className="flex items-center gap-2 mt-1">
                      <span 
                        className="text-xs px-1.5 py-0.5 rounded"
                        style={{ backgroundColor: config.color + '30', color: config.glowColor }}
                      >
                        {config.label}
                      </span>
                      <span className="text-xs text-yellow-400">🔥 {opp.heat}</span>
                    </div>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default TimelineView;
