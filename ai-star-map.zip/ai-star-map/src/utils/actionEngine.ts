import type { Opportunity, ActionSuggestion, Category, UserRole } from '../types';

// 基于规则生成行动建议
export const generateActionSuggestion = (
  opportunity: Opportunity, 
  role: UserRole
): ActionSuggestion => {
  return role === 'developer' ? opportunity.actionDev : opportunity.actionBiz;
};

// 获取热度等级标签
export const getHeatLabel = (heat: number): { label: string; color: string } => {
  if (heat >= 80) return { label: '紧迫关注', color: '#ef4444' };
  if (heat >= 50) return { label: '值得跟踪', color: '#f59e0b' };
  return { label: '观察中', color: '#6b7280' };
};

// 获取类别建议模板
export const getCategoryAdvice = (category: Category, role: UserRole): string => {
  const templates: Record<Category, Record<UserRole, string>> = {
    model_update: {
      developer: '建议尝试新模型API，构建Demo验证能力边界',
      entrepreneur: '关注模型能力提升带来的新应用场景'
    },
    tool_release: {
      developer: '建议评估工具是否可集成到现有工作流',
      entrepreneur: '关注工具普及带来的市场机会'
    },
    trend: {
      developer: '建议快速原型验证，探索技术应用可能性',
      entrepreneur: '建议分析市场空间，寻找差异化切入点'
    },
    breakthrough: {
      developer: '建议跟进论文，尝试复现或应用新技术',
      entrepreneur: '关注技术突破带来的行业变革机会'
    },
    business: {
      developer: '建议了解商业模式，评估技术服务机会',
      entrepreneur: '建议深入调研市场，设计商业方案'
    }
  };
  
  return templates[category][role];
};

// 格式化日期
export const formatDate = (dateStr: string): string => {
  const date = new Date(dateStr);
  const now = new Date();
  const diffDays = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60 * 24));
  
  if (diffDays === 0) return '今天';
  if (diffDays === 1) return '昨天';
  if (diffDays < 7) return `${diffDays}天前`;
  if (diffDays < 30) return `${Math.floor(diffDays / 7)}周前`;
  
  return date.toLocaleDateString('zh-CN', { month: 'short', day: 'numeric' });
};

// 计算趋势（基于热度历史）
export const calculateTrend = (heatHistory: number[]): 'up' | 'down' | 'stable' => {
  if (heatHistory.length < 2) return 'stable';
  
  const recent = heatHistory.slice(-3);
  const earlier = heatHistory.slice(0, -3);
  
  const recentAvg = recent.reduce((a, b) => a + b, 0) / recent.length;
  const earlierAvg = earlier.reduce((a, b) => a + b, 0) / earlier.length;
  
  const change = (recentAvg - earlierAvg) / earlierAvg;
  
  if (change > 0.1) return 'up';
  if (change < -0.1) return 'down';
  return 'stable';
};

// 获取趋势图标
export const getTrendIcon = (trend: 'up' | 'down' | 'stable'): string => {
  switch (trend) {
    case 'up': return '↑';
    case 'down': return '↓';
    case 'stable': return '→';
  }
};

// 获取趋势颜色
export const getTrendColor = (trend: 'up' | 'down' | 'stable'): string => {
  switch (trend) {
    case 'up': return '#22c55e';
    case 'down': return '#ef4444';
    case 'stable': return '#6b7280';
  }
};
