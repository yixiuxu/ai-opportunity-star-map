import type { Opportunity } from '../types';

export const mockOpportunities: Opportunity[] = [
  {
    id: 'opp_001',
    title: 'GPT-5 多模态能力突破',
    summary: '多模态能力大幅提升，可直接处理图像+文本+音频，推理速度提升3倍',
    category: 'model_update',
    heat: 95,
    source: 'OpenAI Blog',
    sourceUrl: 'https://openai.com/blog/gpt5',
    publishDate: '2026-05-08',
    tags: ['GPT-5', 'multimodal', 'AGI'],
    relatedIds: ['opp_002', 'opp_015'],
    actionDev: {
      title: '验证多模态API能力边界',
      steps: [
        '申请GPT-5 API访问权限',
        '构建图像+文本混合输入测试用例',
        '对比GPT-4o性能差异',
        '探索音频处理能力'
      ],
      resources: [
        { name: 'OpenAI API文档', url: 'https://platform.openai.com/docs' },
        { name: '多模态示例代码', url: 'https://github.com/openai/multimodal-examples' }
      ],
      difficulty: 'medium',
      estimatedTime: '4-6小时'
    },
    actionBiz: {
      title: '多模态AI应用市场机会',
      steps: [
        '分析现有竞品的多模态能力',
        '识别垂直领域应用场景',
        '评估技术壁垒和商业价值'
      ],
      resources: [
        { name: '多模态AI市场报告', url: 'https://example.com/report' }
      ],
      difficulty: 'medium',
      estimatedTime: '8-12小时'
    },
    heatHistory: [45, 58, 72, 80, 88, 92, 95]
  },
  {
    id: 'opp_002',
    title: 'Claude 4 发布：200K上下文窗口',
    summary: '上下文窗口扩展至200K tokens，支持超长文档理解，成本降低40%',
    category: 'model_update',
    heat: 88,
    source: 'Anthropic Blog',
    sourceUrl: 'https://anthropic.com/blog/claude-4',
    publishDate: '2026-05-07',
    tags: ['Claude', 'context-window', 'long-context'],
    relatedIds: ['opp_001', 'opp_003'],
    actionDev: {
      title: '长上下文应用场景探索',
      steps: [
        '测试200K上下文的实际效果',
        '构建长文档问答系统Demo',
        '评估成本效益比'
      ],
      resources: [
        { name: 'Claude API', url: 'https://console.anthropic.com' }
      ],
      difficulty: 'easy',
      estimatedTime: '2-4小时'
    },
    actionBiz: {
      title: '企业知识库解决方案机会',
      steps: [
        '调研企业知识管理痛点',
        '设计基于长上下文的解决方案',
        '评估市场规模'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [30, 45, 60, 75, 82, 86, 88]
  },
  {
    id: 'opp_003',
    title: 'Gemini 2.5 Pro 开源版本发布',
    summary: 'Google开源Gemini 2.5 Pro，支持本地部署，性能接近GPT-4',
    category: 'model_update',
    heat: 85,
    source: 'Google AI Blog',
    sourceUrl: 'https://ai.google/blog/gemini-oss',
    publishDate: '2026-05-06',
    tags: ['Gemini', 'open-source', 'local-llm'],
    relatedIds: ['opp_002', 'opp_004'],
    actionDev: {
      title: '本地部署与性能测试',
      steps: [
        '下载模型权重',
        '配置本地推理环境',
        '运行基准测试',
        '对比云端API成本'
      ],
      resources: [
        { name: 'Hugging Face模型页', url: 'https://huggingface.co/google/gemini-2.5-pro' }
      ],
      difficulty: 'hard',
      estimatedTime: '8-12小时'
    },
    actionBiz: {
      title: '私有化部署市场机会',
      steps: [
        '识别对数据隐私敏感的客户',
        '评估私有化部署商业模式',
        '分析竞争格局'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [20, 35, 50, 65, 75, 82, 85]
  },
  {
    id: 'opp_004',
    title: 'LangGraph 2.0：可视化Agent编排',
    summary: '全新可视化Agent编排工具，支持拖拽式工作流设计，降低Agent开发门槛',
    category: 'tool_release',
    heat: 82,
    source: 'LangChain Blog',
    sourceUrl: 'https://blog.langchain.dev/langgraph-2',
    publishDate: '2026-05-05',
    tags: ['LangGraph', 'agent', 'workflow'],
    relatedIds: ['opp_005', 'opp_006'],
    actionDev: {
      title: '构建可视化Agent工作流',
      steps: [
        '安装LangGraph 2.0',
        '尝试可视化编排界面',
        '构建一个简单的多Agent协作Demo'
      ],
      resources: [
        { name: 'LangGraph文档', url: 'https://langchain-ai.github.io/langgraph' }
      ],
      difficulty: 'easy',
      estimatedTime: '2-3小时'
    },
    actionBiz: {
      title: '企业自动化解决方案',
      steps: [
        '识别企业自动化痛点',
        '设计基于Agent的解决方案',
        '评估市场机会'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '4-6小时'
    },
    heatHistory: [25, 40, 55, 68, 75, 80, 82]
  },
  {
    id: 'opp_005',
    title: 'AutoGPT Enterprise 版本发布',
    summary: '企业级自主Agent平台，支持安全沙箱、审计日志、权限管理',
    category: 'tool_release',
    heat: 78,
    source: 'AutoGPT Blog',
    sourceUrl: 'https://autogpt.com/enterprise',
    publishDate: '2026-05-04',
    tags: ['AutoGPT', 'enterprise', 'autonomous-agent'],
    relatedIds: ['opp_004', 'opp_006'],
    actionDev: {
      title: '评估企业级Agent能力',
      steps: [
        '申请Enterprise试用',
        '测试安全沙箱功能',
        '评估API集成难度'
      ],
      resources: [
        { name: 'AutoGPT Enterprise', url: 'https://autogpt.com/enterprise' }
      ],
      difficulty: 'medium',
      estimatedTime: '4-6小时'
    },
    actionBiz: {
      title: '企业自动化转型咨询',
      steps: [
        '调研企业自动化需求',
        '设计Agent自动化方案',
        '评估ROI'
      ],
      resources: [],
      difficulty: 'hard',
      estimatedTime: '8-12小时'
    },
    heatHistory: [30, 42, 55, 65, 72, 76, 78]
  },
  {
    id: 'opp_006',
    title: 'CrewAI 多Agent协作框架',
    summary: '简化多Agent协作开发，支持角色扮演和任务分配，社区活跃度高',
    category: 'tool_release',
    heat: 75,
    source: 'CrewAI GitHub',
    sourceUrl: 'https://github.com/joaomdmoura/crewAI',
    publishDate: '2026-05-03',
    tags: ['CrewAI', 'multi-agent', 'collaboration'],
    relatedIds: ['opp_004', 'opp_005'],
    actionDev: {
      title: '构建多Agent协作Demo',
      steps: [
        '安装CrewAI',
        '定义Agent角色',
        '创建协作任务',
        '测试运行效果'
      ],
      resources: [
        { name: 'CrewAI文档', url: 'https://docs.crewai.com' }
      ],
      difficulty: 'easy',
      estimatedTime: '2-4小时'
    },
    actionBiz: {
      title: '多Agent解决方案商业化',
      steps: [
        '识别多Agent应用场景',
        '评估技术可行性',
        '设计商业模式'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [20, 35, 48, 58, 68, 72, 75]
  },
  {
    id: 'opp_007',
    title: 'AI视频生成：Sora公测开启',
    summary: 'OpenAI开放Sora公测，支持60秒高清视频生成，创意行业迎来变革',
    category: 'trend',
    heat: 92,
    source: 'OpenAI Blog',
    sourceUrl: 'https://openai.com/blog/sora-public-beta',
    publishDate: '2026-05-08',
    tags: ['Sora', 'video-generation', 'creative'],
    relatedIds: ['opp_008', 'opp_009'],
    actionDev: {
      title: '探索视频生成API集成',
      steps: [
        '申请Sora API访问',
        '测试视频生成效果',
        '探索应用场景'
      ],
      resources: [
        { name: 'Sora API文档', url: 'https://platform.openai.com/docs/sora' }
      ],
      difficulty: 'medium',
      estimatedTime: '4-6小时'
    },
    actionBiz: {
      title: 'AI视频内容创作平台',
      steps: [
        '分析视频创作市场',
        '设计差异化产品',
        '评估商业可行性'
      ],
      resources: [],
      difficulty: 'hard',
      estimatedTime: '12-16小时'
    },
    heatHistory: [50, 65, 78, 85, 89, 91, 92]
  },
  {
    id: 'opp_008',
    title: 'Runway Gen-3 视频编辑能力',
    summary: 'Gen-3支持视频编辑、风格迁移、对象替换，专业级视频制作门槛降低',
    category: 'trend',
    heat: 80,
    source: 'Runway Blog',
    sourceUrl: 'https://runwayml.com/blog/gen-3',
    publishDate: '2026-05-06',
    tags: ['Runway', 'video-editing', 'gen-3'],
    relatedIds: ['opp_007', 'opp_009'],
    actionDev: {
      title: '测试视频编辑API',
      steps: [
        '注册Runway账号',
        '测试视频编辑功能',
        '评估API稳定性'
      ],
      resources: [
        { name: 'Runway API', url: 'https://runwayml.com/api' }
      ],
      difficulty: 'easy',
      estimatedTime: '2-3小时'
    },
    actionBiz: {
      title: '视频后期制作服务',
      steps: [
        '分析视频后期市场',
        '设计AI辅助工作流',
        '评估成本优势'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [35, 48, 60, 70, 76, 79, 80]
  },
  {
    id: 'opp_009',
    title: 'Pika Labs 实时视频生成',
    summary: '实时视频生成技术突破，支持交互式视频创作，延迟低于1秒',
    category: 'breakthrough',
    heat: 76,
    source: 'Pika Labs Blog',
    sourceUrl: 'https://pika.art/blog/realtime',
    publishDate: '2026-05-05',
    tags: ['Pika', 'realtime', 'video-generation'],
    relatedIds: ['opp_007', 'opp_008'],
    actionDev: {
      title: '探索实时视频生成',
      steps: [
        '申请Pika API',
        '测试实时生成效果',
        '评估应用场景'
      ],
      resources: [
        { name: 'Pika Labs', url: 'https://pika.art' }
      ],
      difficulty: 'medium',
      estimatedTime: '3-4小时'
    },
    actionBiz: {
      title: '实时视频互动应用',
      steps: [
        '识别实时视频应用场景',
        '设计产品原型',
        '评估技术可行性'
      ],
      resources: [],
      difficulty: 'hard',
      estimatedTime: '8-12小时'
    },
    heatHistory: [25, 40, 52, 62, 70, 74, 76]
  },
  {
    id: 'opp_010',
    title: 'AI代码助手：Cursor 2.0发布',
    summary: 'AI原生IDE重大更新，支持多文件上下文理解，代码生成准确率提升40%',
    category: 'tool_release',
    heat: 88,
    source: 'Cursor Blog',
    sourceUrl: 'https://cursor.sh/blog/cursor-2',
    publishDate: '2026-05-07',
    tags: ['Cursor', 'code-assistant', 'IDE'],
    relatedIds: ['opp_011', 'opp_012'],
    actionDev: {
      title: '升级并测试新功能',
      steps: [
        '更新Cursor到2.0版本',
        '测试多文件上下文功能',
        '评估开发效率提升'
      ],
      resources: [
        { name: 'Cursor官网', url: 'https://cursor.sh' }
      ],
      difficulty: 'easy',
      estimatedTime: '1-2小时'
    },
    actionBiz: {
      title: 'AI辅助开发服务',
      steps: [
        '分析开发者工具市场',
        '设计增值服务',
        '评估商业机会'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '4-6小时'
    },
    heatHistory: [40, 55, 68, 78, 84, 87, 88]
  },
  {
    id: 'opp_011',
    title: 'GitHub Copilot Workspace',
    summary: 'GitHub推出Copilot Workspace，支持自然语言描述任务，自动生成完整项目',
    category: 'tool_release',
    heat: 85,
    source: 'GitHub Blog',
    sourceUrl: 'https://github.blog/copilot-workspace',
    publishDate: '2026-05-06',
    tags: ['GitHub', 'Copilot', 'workspace'],
    relatedIds: ['opp_010', 'opp_012'],
    actionDev: {
      title: '体验Workspace功能',
      steps: [
        '申请Workspace预览',
        '用自然语言创建项目',
        '评估生成质量'
      ],
      resources: [
        { name: 'Copilot Workspace', url: 'https://github.com/features/copilot-workspace' }
      ],
      difficulty: 'easy',
      estimatedTime: '2-3小时'
    },
    actionBiz: {
      title: '低代码开发平台机会',
      steps: [
        '分析低代码市场',
        '评估技术差异化',
        '设计商业模式'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [35, 50, 62, 72, 80, 84, 85]
  },
  {
    id: 'opp_012',
    title: 'Codeium 企业版免费开放',
    summary: 'Codeium企业版对中小企业免费，支持私有化部署和自定义模型',
    category: 'tool_release',
    heat: 72,
    source: 'Codeium Blog',
    sourceUrl: 'https://codeium.com/blog/enterprise-free',
    publishDate: '2026-05-04',
    tags: ['Codeium', 'enterprise', 'free'],
    relatedIds: ['opp_010', 'opp_011'],
    actionDev: {
      title: '部署企业版Codeium',
      steps: [
        '申请企业版许可',
        '配置私有化部署',
        '集成到开发流程'
      ],
      resources: [
        { name: 'Codeium企业版', url: 'https://codeium.com/enterprise' }
      ],
      difficulty: 'medium',
      estimatedTime: '4-6小时'
    },
    actionBiz: {
      title: '企业开发效率提升方案',
      steps: [
        '评估企业开发痛点',
        '设计AI辅助方案',
        '计算ROI'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '4-6小时'
    },
    heatHistory: [20, 32, 45, 55, 65, 70, 72]
  },
  {
    id: 'opp_013',
    title: 'AI Agent在客服领域的应用',
    summary: '智能客服Agent渗透率突破30%，头部企业开始大规模替代人工客服',
    category: 'trend',
    heat: 78,
    source: '行业报告',
    sourceUrl: 'https://example.com/report/customer-service-ai',
    publishDate: '2026-05-05',
    tags: ['customer-service', 'agent', 'automation'],
    relatedIds: ['opp_014', 'opp_005'],
    actionDev: {
      title: '构建客服Agent Demo',
      steps: [
        '设计客服对话流程',
        '选择LLM和知识库方案',
        '实现原型系统'
      ],
      resources: [
        { name: 'Rasa框架', url: 'https://rasa.com' }
      ],
      difficulty: 'medium',
      estimatedTime: '8-12小时'
    },
    actionBiz: {
      title: '智能客服解决方案',
      steps: [
        '调研客服市场痛点',
        '设计差异化方案',
        '评估市场规模'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '8-10小时'
    },
    heatHistory: [30, 42, 55, 65, 72, 76, 78]
  },
  {
    id: 'opp_014',
    title: 'RAG技术成熟度提升',
    summary: 'RAG技术栈趋于成熟，GraphRAG成为新趋势，企业知识库应用加速',
    category: 'breakthrough',
    heat: 82,
    source: '技术博客',
    sourceUrl: 'https://example.com/blog/rag-maturity',
    publishDate: '2026-05-06',
    tags: ['RAG', 'GraphRAG', 'knowledge-base'],
    relatedIds: ['opp_013', 'opp_002'],
    actionDev: {
      title: '学习GraphRAG技术',
      steps: [
        '了解GraphRAG原理',
        '搭建开发环境',
        '构建知识图谱Demo'
      ],
      resources: [
        { name: 'GraphRAG论文', url: 'https://arxiv.org/abs/graphrag' },
        { name: 'Microsoft GraphRAG', url: 'https://github.com/microsoft/graphrag' }
      ],
      difficulty: 'hard',
      estimatedTime: '12-16小时'
    },
    actionBiz: {
      title: '企业知识库解决方案',
      steps: [
        '识别知识管理痛点',
        '设计GraphRAG方案',
        '评估商业价值'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '8-10小时'
    },
    heatHistory: [25, 40, 55, 68, 76, 80, 82]
  },
  {
    id: 'opp_015',
    title: '多模态AI医疗诊断突破',
    summary: '多模态AI在医学影像诊断准确率超过专家，FDA批准首个AI诊断系统',
    category: 'breakthrough',
    heat: 90,
    source: '医疗AI报告',
    sourceUrl: 'https://example.com/report/medical-ai',
    publishDate: '2026-05-08',
    tags: ['medical-ai', 'diagnosis', 'multimodal'],
    relatedIds: ['opp_001', 'opp_016'],
    actionDev: {
      title: '了解医疗AI技术栈',
      steps: [
        '学习医学影像处理',
        '了解合规要求',
        '探索开源模型'
      ],
      resources: [
        { name: 'MONAI框架', url: 'https://monai.io' }
      ],
      difficulty: 'hard',
      estimatedTime: '16-24小时'
    },
    actionBiz: {
      title: '医疗AI商业化机会',
      steps: [
        '分析医疗AI市场',
        '了解监管要求',
        '评估进入壁垒'
      ],
      resources: [],
      difficulty: 'hard',
      estimatedTime: '12-16小时'
    },
    heatHistory: [40, 55, 70, 80, 86, 89, 90]
  },
  {
    id: 'opp_016',
    title: 'AI制药研发效率提升',
    summary: 'AI加速药物发现，研发周期缩短50%，多家药企宣布AI管线进展',
    category: 'business',
    heat: 75,
    source: '医药行业报告',
    sourceUrl: 'https://example.com/report/ai-pharma',
    publishDate: '2026-05-05',
    tags: ['pharma', 'drug-discovery', 'AI'],
    relatedIds: ['opp_015', 'opp_017'],
    actionDev: {
      title: '了解AI制药技术',
      steps: [
        '学习分子生成模型',
        '了解药物发现流程',
        '探索开源工具'
      ],
      resources: [
        { name: 'DeepChem', url: 'https://deepchem.io' }
      ],
      difficulty: 'hard',
      estimatedTime: '20-30小时'
    },
    actionBiz: {
      title: 'AI制药服务机会',
      steps: [
        '分析制药行业痛点',
        '评估技术服务机会',
        '了解行业门槛'
      ],
      resources: [],
      difficulty: 'hard',
      estimatedTime: '12-16小时'
    },
    heatHistory: [20, 35, 48, 60, 68, 73, 75]
  },
  {
    id: 'opp_017',
    title: 'AI教育个性化学习平台',
    summary: 'AI驱动的个性化学习平台快速增长，用户留存率提升40%',
    category: 'business',
    heat: 80,
    source: '教育科技报告',
    sourceUrl: 'https://example.com/report/ai-education',
    publishDate: '2026-05-06',
    tags: ['education', 'personalization', 'AI'],
    relatedIds: ['opp_018', 'opp_019'],
    actionDev: {
      title: '构建个性化学习Demo',
      steps: [
        '设计学习路径算法',
        '实现内容推荐系统',
        '集成LLM对话功能'
      ],
      resources: [
        { name: 'Khan Academy API', url: 'https://www.khanacademy.org/api' }
      ],
      difficulty: 'medium',
      estimatedTime: '12-16小时'
    },
    actionBiz: {
      title: 'AI教育产品机会',
      steps: [
        '分析教育市场痛点',
        '设计差异化产品',
        '评估商业模式'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '8-10小时'
    },
    heatHistory: [30, 45, 58, 68, 75, 78, 80]
  },
  {
    id: 'opp_018',
    title: 'AI写作助手市场爆发',
    summary: 'AI写作工具市场规模突破50亿美元，企业内容创作需求激增',
    category: 'business',
    heat: 76,
    source: '市场研究报告',
    sourceUrl: 'https://example.com/report/ai-writing',
    publishDate: '2026-05-04',
    tags: ['writing', 'content-creation', 'market'],
    relatedIds: ['opp_017', 'opp_019'],
    actionDev: {
      title: '构建写作助手原型',
      steps: [
        '选择LLM和提示策略',
        '实现写作辅助功能',
        '添加风格定制能力'
      ],
      resources: [
        { name: 'Jasper API', url: 'https://www.jasper.ai/api' }
      ],
      difficulty: 'easy',
      estimatedTime: '6-8小时'
    },
    actionBiz: {
      title: '企业内容服务机会',
      steps: [
        '分析企业内容需求',
        '设计差异化服务',
        '评估市场规模'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [25, 38, 52, 62, 70, 74, 76]
  },
  {
    id: 'opp_019',
    title: 'AI翻译质量接近人工',
    summary: '神经机器翻译质量达到人工水平，实时翻译应用快速增长',
    category: 'breakthrough',
    heat: 72,
    source: '语言技术报告',
    sourceUrl: 'https://example.com/report/ai-translation',
    publishDate: '2026-05-03',
    tags: ['translation', 'NMT', 'realtime'],
    relatedIds: ['opp_018', 'opp_020'],
    actionDev: {
      title: '集成翻译API',
      steps: [
        '选择翻译服务',
        '实现实时翻译功能',
        '优化翻译质量'
      ],
      resources: [
        { name: 'DeepL API', url: 'https://www.deepl.com/api' }
      ],
      difficulty: 'easy',
      estimatedTime: '3-4小时'
    },
    actionBiz: {
      title: '跨境沟通服务机会',
      steps: [
        '分析翻译市场需求',
        '设计增值服务',
        '评估商业可行性'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [20, 32, 45, 55, 65, 70, 72]
  },
  {
    id: 'opp_020',
    title: 'AI语音合成技术突破',
    summary: '零样本语音克隆技术成熟，3秒音频即可复制声音，应用场景扩展',
    category: 'breakthrough',
    heat: 85,
    source: '语音技术博客',
    sourceUrl: 'https://example.com/blog/voice-synthesis',
    publishDate: '2026-05-07',
    tags: ['voice-synthesis', 'TTS', 'voice-cloning'],
    relatedIds: ['opp_019', 'opp_021'],
    actionDev: {
      title: '测试语音克隆API',
      steps: [
        '选择语音合成服务',
        '测试克隆效果',
        '评估应用场景'
      ],
      resources: [
        { name: 'ElevenLabs', url: 'https://elevenlabs.io' }
      ],
      difficulty: 'easy',
      estimatedTime: '2-3小时'
    },
    actionBiz: {
      title: '语音内容服务机会',
      steps: [
        '分析语音内容市场',
        '设计差异化产品',
        '评估合规风险'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [35, 50, 62, 72, 80, 84, 85]
  },
  {
    id: 'opp_021',
    title: 'AI音乐生成商业化',
    summary: 'AI音乐生成平台Suno、Udio商业化加速，版权问题逐步解决',
    category: 'business',
    heat: 78,
    source: '音乐科技报告',
    sourceUrl: 'https://example.com/report/ai-music',
    publishDate: '2026-05-05',
    tags: ['music-generation', 'Suno', 'Udio'],
    relatedIds: ['opp_020', 'opp_007'],
    actionDev: {
      title: '探索音乐生成API',
      steps: [
        '测试Suno/Udio API',
        '生成音乐样本',
        '评估商业用途'
      ],
      resources: [
        { name: 'Suno API', url: 'https://suno.ai/api' }
      ],
      difficulty: 'easy',
      estimatedTime: '2-3小时'
    },
    actionBiz: {
      title: 'AI音乐内容平台',
      steps: [
        '分析音乐内容市场',
        '设计商业模式',
        '评估版权风险'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '8-10小时'
    },
    heatHistory: [28, 42, 55, 65, 72, 76, 78]
  },
  {
    id: 'opp_022',
    title: 'AI图像生成：Midjourney V7',
    summary: 'Midjourney V7发布，图像质量和一致性大幅提升，支持视频生成',
    category: 'model_update',
    heat: 88,
    source: 'Midjourney Blog',
    sourceUrl: 'https://midjourney.com/blog/v7',
    publishDate: '2026-05-07',
    tags: ['Midjourney', 'image-generation', 'V7'],
    relatedIds: ['opp_023', 'opp_007'],
    actionDev: {
      title: '测试V7新功能',
      steps: [
        '订阅Midjourney',
        '测试图像生成效果',
        '探索视频生成功能'
      ],
      resources: [
        { name: 'Midjourney', url: 'https://midjourney.com' }
      ],
      difficulty: 'easy',
      estimatedTime: '2-3小时'
    },
    actionBiz: {
      title: 'AI视觉内容服务',
      steps: [
        '分析视觉内容市场',
        '设计差异化服务',
        '评估商业可行性'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [40, 55, 68, 78, 84, 87, 88]
  },
  {
    id: 'opp_023',
    title: 'Stable Diffusion 4 开源',
    summary: 'Stability AI发布SD4，开源图像生成新标杆，支持本地高效运行',
    category: 'model_update',
    heat: 82,
    source: 'Stability AI Blog',
    sourceUrl: 'https://stability.ai/blog/sd4',
    publishDate: '2026-05-06',
    tags: ['Stable-Diffusion', 'open-source', 'SD4'],
    relatedIds: ['opp_022', 'opp_024'],
    actionDev: {
      title: '部署SD4本地环境',
      steps: [
        '下载模型权重',
        '配置推理环境',
        '测试生成效果'
      ],
      resources: [
        { name: 'Hugging Face', url: 'https://huggingface.co/stabilityai/sd4' }
      ],
      difficulty: 'medium',
      estimatedTime: '4-6小时'
    },
    actionBiz: {
      title: '私有化图像生成服务',
      steps: [
        '分析企业需求',
        '设计私有化方案',
        '评估成本优势'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [30, 45, 58, 70, 78, 81, 82]
  },
  {
    id: 'opp_024',
    title: 'AI 3D建模工具崛起',
    summary: 'AI 3D建模工具快速成熟，文本生成3D模型质量显著提升',
    category: 'trend',
    heat: 75,
    source: '3D技术报告',
    sourceUrl: 'https://example.com/report/ai-3d',
    publishDate: '2026-05-04',
    tags: ['3D-modeling', 'text-to-3D', 'AI'],
    relatedIds: ['opp_023', 'opp_025'],
    actionDev: {
      title: '测试3D生成工具',
      steps: [
        '尝试Meshy、Tripo等工具',
        '生成3D模型样本',
        '评估应用场景'
      ],
      resources: [
        { name: 'Meshy AI', url: 'https://meshy.ai' }
      ],
      difficulty: 'easy',
      estimatedTime: '2-3小时'
    },
    actionBiz: {
      title: '3D内容创作服务',
      steps: [
        '分析3D内容市场',
        '设计服务方案',
        '评估商业可行性'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [22, 35, 48, 60, 68, 73, 75]
  },
  {
    id: 'opp_025',
    title: 'AI游戏开发工具链',
    summary: 'AI辅助游戏开发工具链成熟，从美术到代码全流程AI化',
    category: 'trend',
    heat: 78,
    source: '游戏开发报告',
    sourceUrl: 'https://example.com/report/ai-game-dev',
    publishDate: '2026-05-05',
    tags: ['game-dev', 'AI-tools', 'automation'],
    relatedIds: ['opp_024', 'opp_026'],
    actionDev: {
      title: '探索AI游戏开发工具',
      steps: [
        '了解AI游戏工具生态',
        '测试关键工具',
        '评估效率提升'
      ],
      resources: [
        { name: 'Unity AI', url: 'https://unity.com/ai' }
      ],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    actionBiz: {
      title: '独立游戏开发服务',
      steps: [
        '分析独立游戏市场',
        '设计AI辅助方案',
        '评估商业机会'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '8-10小时'
    },
    heatHistory: [25, 38, 52, 64, 72, 76, 78]
  },
  {
    id: 'opp_026',
    title: 'AI自动化测试工具',
    summary: 'AI驱动的自动化测试工具普及，测试效率提升60%',
    category: 'tool_release',
    heat: 70,
    source: '软件测试报告',
    sourceUrl: 'https://example.com/report/ai-testing',
    publishDate: '2026-05-03',
    tags: ['testing', 'automation', 'QA'],
    relatedIds: ['opp_025', 'opp_010'],
    actionDev: {
      title: '集成AI测试工具',
      steps: [
        '选择AI测试工具',
        '集成到CI/CD',
        '评估测试覆盖率'
      ],
      resources: [
        { name: 'Testim', url: 'https://www.testim.io' }
      ],
      difficulty: 'medium',
      estimatedTime: '4-6小时'
    },
    actionBiz: {
      title: '测试服务外包机会',
      steps: [
        '分析测试外包市场',
        '设计AI测试服务',
        '评估成本优势'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [18, 30, 42, 54, 62, 68, 70]
  },
  {
    id: 'opp_027',
    title: 'AI数据分析平台',
    summary: '自然语言数据分析平台成熟，非技术用户也能做复杂分析',
    category: 'tool_release',
    heat: 82,
    source: '数据分析报告',
    sourceUrl: 'https://example.com/report/ai-analytics',
    publishDate: '2026-05-06',
    tags: ['analytics', 'natural-language', 'BI'],
    relatedIds: ['opp_028', 'opp_014'],
    actionDev: {
      title: '构建NL数据分析Demo',
      steps: [
        '选择LLM和分析框架',
        '实现自然语言查询',
        '添加可视化功能'
      ],
      resources: [
        { name: 'PandasAI', url: 'https://pandas-ai.com' }
      ],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    actionBiz: {
      title: '企业数据分析服务',
      steps: [
        '分析企业分析需求',
        '设计差异化方案',
        '评估市场规模'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [28, 42, 55, 66, 74, 79, 82]
  },
  {
    id: 'opp_028',
    title: 'AI驱动的BI工具',
    summary: '传统BI工具集成AI能力，自动洞察和预测成为标配',
    category: 'trend',
    heat: 76,
    source: 'BI行业报告',
    sourceUrl: 'https://example.com/report/ai-bi',
    publishDate: '2026-05-04',
    tags: ['BI', 'insights', 'prediction'],
    relatedIds: ['opp_027', 'opp_029'],
    actionDev: {
      title: '探索AI BI工具',
      steps: [
        '测试主流AI BI工具',
        '评估集成难度',
        '设计自定义方案'
      ],
      resources: [
        { name: 'Tableau AI', url: 'https://www.tableau.com/ai' }
      ],
      difficulty: 'easy',
      estimatedTime: '3-4小时'
    },
    actionBiz: {
      title: 'BI咨询与实施服务',
      steps: [
        '分析BI市场需求',
        '设计服务方案',
        '评估商业机会'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [22, 35, 48, 60, 68, 73, 76]
  },
  {
    id: 'opp_029',
    title: 'AI安全与合规工具',
    summary: 'AI安全工具市场快速增长，企业AI治理需求激增',
    category: 'business',
    heat: 80,
    source: 'AI安全报告',
    sourceUrl: 'https://example.com/report/ai-security',
    publishDate: '2026-05-05',
    tags: ['security', 'compliance', 'governance'],
    relatedIds: ['opp_028', 'opp_030'],
    actionDev: {
      title: '了解AI安全工具',
      steps: [
        '学习AI安全框架',
        '测试安全检测工具',
        '评估合规要求'
      ],
      resources: [
        { name: 'NIST AI框架', url: 'https://www.nist.gov/itl/ai-risk-management-framework' }
      ],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    actionBiz: {
      title: 'AI合规咨询服务',
      steps: [
        '分析合规市场需求',
        '设计服务方案',
        '评估专业门槛'
      ],
      resources: [],
      difficulty: 'hard',
      estimatedTime: '10-12小时'
    },
    heatHistory: [25, 40, 52, 64, 72, 77, 80]
  },
  {
    id: 'opp_030',
    title: 'AI人才培训市场',
    summary: 'AI技能培训市场爆发，企业AI转型催生巨大培训需求',
    category: 'business',
    heat: 85,
    source: '教育市场报告',
    sourceUrl: 'https://example.com/report/ai-training',
    publishDate: '2026-05-07',
    tags: ['training', 'upskilling', 'enterprise'],
    relatedIds: ['opp_029', 'opp_017'],
    actionDev: {
      title: '开发AI培训内容',
      steps: [
        '设计课程大纲',
        '制作教学材料',
        '开发实践项目'
      ],
      resources: [
        { name: 'DeepLearning.AI', url: 'https://www.deeplearning.ai' }
      ],
      difficulty: 'medium',
      estimatedTime: '20-30小时'
    },
    actionBiz: {
      title: '企业AI培训服务',
      steps: [
        '分析企业培训需求',
        '设计培训方案',
        '评估市场规模'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '8-10小时'
    },
    heatHistory: [35, 50, 62, 72, 80, 84, 85]
  },
  {
    id: 'opp_031',
    title: 'Llama 4 开源发布',
    summary: 'Meta发布Llama 4，参数规模达1T，性能接近GPT-5，完全开源',
    category: 'model_update',
    heat: 92,
    source: 'Meta AI Blog',
    sourceUrl: 'https://ai.meta.com/blog/llama-4',
    publishDate: '2026-05-08',
    tags: ['Llama', 'open-source', 'Meta'],
    relatedIds: ['opp_001', 'opp_003'],
    actionDev: {
      title: '部署Llama 4测试',
      steps: [
        '下载模型权重',
        '配置推理环境',
        '运行基准测试'
      ],
      resources: [
        { name: 'Hugging Face', url: 'https://huggingface.co/meta-llama/Llama-4' }
      ],
      difficulty: 'hard',
      estimatedTime: '8-12小时'
    },
    actionBiz: {
      title: '开源模型商业化',
      steps: [
        '分析开源模型市场',
        '设计增值服务',
        '评估商业可行性'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '8-10小时'
    },
    heatHistory: [45, 60, 75, 83, 88, 91, 92]
  },
  {
    id: 'opp_032',
    title: 'AI Agent开发框架对比',
    summary: '主流Agent框架功能对比：LangGraph vs CrewAI vs AutoGen，选择指南',
    category: 'trend',
    heat: 75,
    source: '技术博客',
    sourceUrl: 'https://example.com/blog/agent-frameworks',
    publishDate: '2026-05-04',
    tags: ['agent', 'framework', 'comparison'],
    relatedIds: ['opp_004', 'opp_005', 'opp_006'],
    actionDev: {
      title: '对比测试Agent框架',
      steps: [
        '搭建各框架环境',
        '实现相同任务',
        '对比性能和易用性'
      ],
      resources: [
        { name: 'LangGraph', url: 'https://langchain-ai.github.io/langgraph' },
        { name: 'CrewAI', url: 'https://docs.crewai.com' }
      ],
      difficulty: 'medium',
      estimatedTime: '8-12小时'
    },
    actionBiz: {
      title: 'Agent开发服务',
      steps: [
        '分析企业Agent需求',
        '选择合适框架',
        '设计服务方案'
      ],
      resources: [],
      difficulty: 'medium',
      estimatedTime: '6-8小时'
    },
    heatHistory: [20, 35, 48, 60, 68, 73, 75]
  }
];

// 获取所有标签
export const getAllTags = (): string[] => {
  const tagSet = new Set<string>();
  mockOpportunities.forEach(opp => {
    opp.tags.forEach(tag => tagSet.add(tag));
  });
  return Array.from(tagSet).sort();
};

// 获取关联关系（用于图谱）
export const getRelations = () => {
  const relations: { source: string; target: string }[] = [];
  mockOpportunities.forEach(opp => {
    opp.relatedIds.forEach(relatedId => {
      // 避免重复
      if (opp.id < relatedId) {
        relations.push({ source: opp.id, target: relatedId });
      }
    });
  });
  return relations;
};
