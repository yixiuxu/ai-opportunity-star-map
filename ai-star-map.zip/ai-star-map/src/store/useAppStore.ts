import { create } from 'zustand';
import type { Opportunity, UserRole, ViewType, OpportunityStatus, FilterState } from '../types';
import { mockOpportunities } from '../data/mockData';

interface AppState {
  // 数据
  opportunities: Opportunity[];
  selectedOpportunity: Opportunity | null;
  
  // UI状态
  currentView: ViewType;
  userRole: UserRole;
  isPanelOpen: boolean;
  isFilterOpen: boolean;
  
  // 筛选
  filters: FilterState;
  
  // 用户追踪
  watchedOpportunities: Map<string, OpportunityStatus>;
  
  // Actions
  setCurrentView: (view: ViewType) => void;
  setUserRole: (role: UserRole) => void;
  setSelectedOpportunity: (opp: Opportunity | null) => void;
  togglePanel: () => void;
  toggleFilter: () => void;
  setFilters: (filters: Partial<FilterState>) => void;
  setOpportunityStatus: (id: string, status: OpportunityStatus) => void;
  
  // 计算属性
  getFilteredOpportunities: () => Opportunity[];
  getWatchedCount: () => number;
}

const defaultFilters: FilterState = {
  categories: [],
  minHeat: 0,
  maxHeat: 100,
  dateRange: ['2026-04-01', '2026-05-31'],
  searchQuery: '',
  tags: [],
};

export const useAppStore = create<AppState>((set, get) => ({
  // 初始数据
  opportunities: mockOpportunities,
  selectedOpportunity: null,
  
  // UI状态
  currentView: 'starmap',
  userRole: 'developer',
  isPanelOpen: false,
  isFilterOpen: true,
  
  // 筛选
  filters: defaultFilters,
  
  // 用户追踪
  watchedOpportunities: new Map(),
  
  // Actions
  setCurrentView: (view) => set({ currentView: view }),
  
  setUserRole: (role) => set({ userRole: role }),
  
  setSelectedOpportunity: (opp) => set({ 
    selectedOpportunity: opp,
    isPanelOpen: opp !== null
  }),
  
  togglePanel: () => set((state) => ({ 
    isPanelOpen: !state.isPanelOpen,
    selectedOpportunity: state.isPanelOpen ? null : state.selectedOpportunity
  })),
  
  toggleFilter: () => set((state) => ({ isFilterOpen: !state.isFilterOpen })),
  
  setFilters: (newFilters) => set((state) => ({
    filters: { ...state.filters, ...newFilters }
  })),
  
  setOpportunityStatus: (id, status) => set((state) => {
    const newMap = new Map(state.watchedOpportunities);
    if (status === 'none') {
      newMap.delete(id);
    } else {
      newMap.set(id, status);
    }
    return { watchedOpportunities: newMap };
  }),
  
  // 计算属性
  getFilteredOpportunities: () => {
    const { opportunities, filters } = get();
    
    return opportunities.filter(opp => {
      // 类别筛选
      if (filters.categories.length > 0 && !filters.categories.includes(opp.category)) {
        return false;
      }
      
      // 热度筛选
      if (opp.heat < filters.minHeat || opp.heat > filters.maxHeat) {
        return false;
      }
      
      // 搜索筛选
      if (filters.searchQuery) {
        const query = filters.searchQuery.toLowerCase();
        const matchTitle = opp.title.toLowerCase().includes(query);
        const matchSummary = opp.summary.toLowerCase().includes(query);
        const matchTags = opp.tags.some(tag => tag.toLowerCase().includes(query));
        if (!matchTitle && !matchSummary && !matchTags) {
          return false;
        }
      }
      
      // 标签筛选
      if (filters.tags.length > 0) {
        const hasTag = filters.tags.some(tag => opp.tags.includes(tag));
        if (!hasTag) return false;
      }
      
      return true;
    });
  },
  
  getWatchedCount: () => {
    const { watchedOpportunities } = get();
    return watchedOpportunities.size;
  },
}));
