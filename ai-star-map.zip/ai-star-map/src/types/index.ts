// AI机会类别
export type Category = 
  | 'model_update'    // 模型更新
  | 'tool_release'    // 工具发布
  | 'trend'           // 行业趋势
  | 'breakthrough'    // 技术突破
  | 'business';       // 商业机会

// 用户角色
export type UserRole = 'developer' | 'entrepreneur';

// 视图类型
export type ViewType = 'starmap' | 'graph' | 'timeline';

// 机会状态
export type OpportunityStatus = 'none' | 'watching' | 'in_progress' | 'completed';

// 行动建议
export interface ActionSuggestion {
  title: string;
  steps: string[];
  resources: { name: string; url: string }[];
  difficulty: 'easy' | 'medium' | 'hard';
  estimatedTime: string;
}

// AI机会节点
export interface Opportunity {
  id: string;
  title: string;
  summary: string;
  category: Category;
  heat: number;  // 0-100
  source: string;
  sourceUrl: string;
  publishDate: string;
  tags: string[];
  relatedIds: string[];
  actionDev: ActionSuggestion;
  actionBiz: ActionSuggestion;
  heatHistory: number[];  // 7天历史热度
  // 3D位置（运行时计算）
  position?: [number, number, number];
}

// 筛选条件
export interface FilterState {
  categories: Category[];
  minHeat: number;
  maxHeat: number;
  dateRange: [string, string];
  searchQuery: string;
  tags: string[];
}

// 类别配置
export const CATEGORY_CONFIG: Record<Category, { label: string; color: string; glowColor: string }> = {
  model_update: { 
    label: '模型更新', 
    color: '#3b82f6', 
    glowColor: '#60a5fa' 
  },
  tool_release: { 
    label: '工具发布', 
    color: '#22c55e', 
    glowColor: '#4ade80' 
  },
  trend: { 
    label: '行业趋势', 
    color: '#f97316', 
    glowColor: '#fb923c' 
  },
  breakthrough: { 
    label: '技术突破', 
    color: '#a855f7', 
    glowColor: '#c084fc' 
  },
  business: { 
    label: '商业机会', 
    color: '#eab308', 
    glowColor: '#facc15' 
  },
};

// 热度等级
export const getHeatLevel = (heat: number): 'urgent' | 'worth_tracking' | 'observing' => {
  if (heat >= 80) return 'urgent';
  if (heat >= 50) return 'worth_tracking';
  return 'observing';
};

export const HEAT_LEVEL_CONFIG = {
  urgent: { label: '紧迫关注', color: '#ef4444' },
  worth_tracking: { label: '值得跟踪', color: '#f59e0b' },
  observing: { label: '观察中', color: '#6b7280' },
};
