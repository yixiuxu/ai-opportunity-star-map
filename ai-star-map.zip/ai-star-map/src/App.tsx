import { lazy, Suspense } from 'react';
import { useAppStore } from './store/useAppStore';
import Navbar from './components/Layout/Navbar';
import FilterPanel from './components/Layout/FilterPanel';
import ActionPanel from './components/ActionPanel/ActionPanel';

// 懒加载视图组件
const StarMap3D = lazy(() => import('./components/StarMap/StarMap3D'));
const GraphView = lazy(() => import('./components/GraphView/GraphView'));
const TimelineView = lazy(() => import('./components/Timeline/TimelineView'));

// 加载占位符
const LoadingFallback = () => (
  <div className="w-full h-full flex items-center justify-center bg-[#050510]">
    <div className="text-center">
      <div className="text-4xl mb-4 animate-pulse">✨</div>
      <div className="text-gray-400">加载中...</div>
    </div>
  </div>
);

function App() {
  const { currentView, isFilterOpen } = useAppStore();
  
  // 根据视图类型渲染对应组件
  const renderView = () => {
    switch (currentView) {
      case 'starmap':
        return <StarMap3D />;
      case 'graph':
        return <GraphView />;
      case 'timeline':
        return <TimelineView />;
      default:
        return <StarMap3D />;
    }
  };
  
  return (
    <div className="w-full h-screen flex flex-col overflow-hidden bg-[#050510]">
      {/* 顶部导航栏 */}
      <Navbar />
      
      {/* 主内容区 */}
      <div className="flex-1 relative overflow-hidden">
        {/* 左侧筛选面板 */}
        <FilterPanel />
        
        {/* 主视图区域 */}
        <div 
          className="absolute inset-0 transition-all duration-300"
          style={{ left: isFilterOpen ? 224 : 0 }}
        >
          <Suspense fallback={<LoadingFallback />}>
            {renderView()}
          </Suspense>
        </div>
        
        {/* 右侧详情面板 */}
        <ActionPanel />
      </div>
      
      {/* 底部状态栏 */}
      <footer className="h-8 bg-[#0a0a12]/90 border-t border-white/10 flex items-center justify-between px-4 text-xs text-gray-500">
        <div className="flex items-center gap-4">
          <span>AI机会星图与行动推进器</span>
          <span className="text-gray-600">|</span>
          <span>TRAE SOLO 挑战赛</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-green-400">●</span>
          <span>在线</span>
        </div>
      </footer>
    </div>
  );
}

export default App;
